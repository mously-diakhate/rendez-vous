package com;

import java.util.ArrayList;
import java.util.Scanner;

import com.Repository.bd.impl.MedecinRepositoryImpl;
import com.Repository.bd.impl.PatientRepositoryImpl;
import com.Repository.core.ITables;
import com.Services.PersonneServiceImpl;
import com.Services.RendezVousServiceImpl;
import com.entities.Medecin;
import com.entities.Patient;
import com.entities.RendezVous;

public class Main {
    public static void main(String[] args) throws Exception {
        int choix;
        try (Scanner scanner = new Scanner(System.in)) {
            ITables<Patient> yourPatientRepository = new PatientRepositoryImpl();
            ITables<Patient> yourMedecinRepository = new MedecinRepositoryImpl();

            RendezVousServiceImpl rendezVousService = new RendezVousServiceImpl();

            do {
                System.out.println("-------App---------");
                System.out.println("-------RV---------");
                System.out.println("1-Créer un patient");
                System.out.println("2-Créer un médecin");
                System.out.println("3-Planifier un rendez-vous");
                System.out.println("4-Afficher les rendez-vous du jour");
                System.out.println("5-Afficher les rendez-vous d'un médecin par jour");
                System.out.println("6-Annuler un rendez-vous");
                System.out.println("7-Quitter");

                choix = scanner.nextInt();
                scanner.nextLine();

                switch (choix) {
                    case 1:
                        System.out.println("Création d'un patient :");
                        System.out.print("Nom complet du patient : ");
                        String nomComplet = scanner.nextLine();
                        System.out.print("Antécédents médicaux du patient : ");
                        String antecedent = scanner.nextLine();

                        Patient patient = new Patient(nomComplet, antecedent);
                        patient.setType("Patient");

                        PersonneServiceImpl personneService = new PersonneServiceImpl(yourPatientRepository);
                        int result = personneService.add(patient);

                        if (result > 0) {
                            System.out.println("Patient créé avec succès !");
                        } else {
                            System.out.println("Erreur lors de la création du patient.");
                        }
                        break;

                    case 2:
                        System.out.println("Création d'un médecin :");
                        System.out.print("Nom complet du médecin : ");
                        String nomCompletMedecin = scanner.nextLine();
                        System.out.print("Spécialité du médecin : ");
                        String specialiteMedecin = scanner.nextLine();

                        Medecin medecin = new Medecin(nomCompletMedecin, specialiteMedecin);
                        medecin.setType("Medecin");

                        PersonneServiceImpl personneServiceMedecin = new PersonneServiceImpl(yourMedecinRepository);
                        int resultMedecin = personneServiceMedecin.add(medecin);

                        if (resultMedecin > 0) {
                            System.out.println("Médecin créé avec succès !");
                        } else {
                            System.out.println("Erreur lors de la création du médecin.");
                        }
                        break;

                    case 3:
                        System.out.println("Planification d'un rendez-vous :");
                        System.out.print("ID du patient : ");
                        int idPatient = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("ID du médecin : ");
                        int idMedecin = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Date du rendez-vous : ");
                        String dateRendezVous = scanner.nextLine();

                        RendezVous rendezVous = new RendezVous(idPatient, idMedecin, dateRendezVous);

                        int resultRendezVous = rendezVousService.add(rendezVous);

                        if (resultRendezVous > 0) {
                            System.out.println("Rendez-vous créé avec succès !");
                        } else {
                            System.out.println("Erreur lors de la création du rendez-vous.");
                        }
                        break;

                    case 4:
                        System.out.println("Affichage des rendez-vous du jour :");
                        System.out.print("Date du jour (au format YYYY-MM-DD) : ");
                        String dateDuJour = scanner.nextLine();

                        final ArrayList<RendezVous> rendezVousDuJour = rendezVousService.getRendezVousByDate(dateDuJour);

                        if (rendezVousDuJour.size() > 0) {
                            System.out.println("Rendez-vous du jour :");
                            for (RendezVous rv : rendezVousDuJour) {
                                System.out.println("ID du patient : " + rv.getIdPatient());
                                System.out.println("ID du médecin : " + rv.getIdMedecin());
                                System.out.println("Date du rendez-vous : " + rv.getDateRendezVous());
                                System.out.println();
                            }
                        } else {
                            System.out.println("Aucun rendez-vous pour cette date.");
                        }
                        break;

                    case 5:
                        System.out.println("Affichage des rendez-vous d'un médecin par jour :");
                        System.out.print("ID du médecin : ");
                        int idMedecinRv = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Date du jour (au format YYYY-MM-DD) : ");
                        String dateDuJourRv = scanner.nextLine();
                        final ArrayList<RendezVous> rendezVousMedecinJour = rendezVousService.getRendezVousMedecinByDate(idMedecinRv, dateDuJourRv);

                        if (rendezVousMedecinJour.size() > 0) {
                            System.out.println("Rendez-vous du médecin pour le jour :");
                            for (RendezVous rv : rendezVousMedecinJour) {
                                System.out.println("ID du patient : " + rv.getIdPatient());
                                System.out.println("ID du médecin : " + rv.getIdMedecin());
                                System.out.println("Date du rendez-vous : " + rv.getDateRendezVous());
                                System.out.println();
                            }
                        } else {
                            System.out.println("Aucun rendez-vous pour ce médecin à cette date.");
                        }
                        break;

                    case 6:
                        System.out.println("Annulation d'un rendez-vous :");
                        System.out.print("ID du rendez-vous à annuler : ");
                        int idRendezVousAAnnuler = scanner.nextInt();
                        scanner.nextLine();
                        boolean annulationReussie = rendezVousService.annulerRendezVous(idRendezVousAAnnuler);

                        if (annulationReussie) {
                            System.out.println("Rendez-vous annulé avec succès !");
                        } else {
                            System.out.println("Erreur lors de l'annulation du rendez-vous.");
                        }
                        break;
                    default:
                        break;
                }
            } while (choix != 7);
        }
    }
}
