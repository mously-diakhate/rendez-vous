package com.Services;

import com.entities.Medecin;
import com.entities.Patient;
import com.entities.Personne;
import com.Repository.core.ITables;

import java.util.ArrayList;

public class PersonneServiceImpl implements PersonneService {

    private ITables<Patient> personneRepository;

    public PersonneServiceImpl(ITables<Patient> yourPatientRepository) {
        this.personneRepository = yourPatientRepository;
    }
    

	@Override
    public int add(Personne personne) {
        return personneRepository.insert(personne);
    }

    @Override
    public ArrayList<Personne> getAll() {
        return personneRepository.findAll();
    }

    @Override
    public int update(Personne personne) {
        return personneRepository.update(personne);
    }

    @Override
    public Personne show(int id) {
        return personneRepository.findByID(id);
    }

    @Override
    public int remove(int id) {
        return personneRepository.delete(id);
    }

    @Override
    public int[] remove(int[] ids) {
        int[] idsNotDelete = new int[ids.length];
        int n = 0;
        for (int id : ids) {
            if (personneRepository.delete(id) == 0) {
                idsNotDelete[n++] = id;
            }
        }
        return idsNotDelete;
    }
}
