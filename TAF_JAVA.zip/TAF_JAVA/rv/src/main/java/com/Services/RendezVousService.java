package com.Services;

import java.util.ArrayList;

import com.entities.RendezVous;

public class RendezVousService {

    public int add(RendezVous rendezVous) {
        return 0;
    }

    public ArrayList<RendezVous> getRendezVousByDate(String dateDuJour) {
        return null;
    }

}
