package com.Services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.entities.RendezVous;
import com.Repository.bd.MysqlRepository;

public class RendezVousServiceImpl {

    public int add(RendezVous rendezVous) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            String SQL_INSERT = "INSERT INTO rendez_vous (idPatient, idMedecin, dateRendezVous) VALUES (?, ?, ?)";
            PreparedStatement statement = prepareStatement(conn, SQL_INSERT, rendezVous.getIdPatient(), rendezVous.getIdMedecin(), rendezVous.getDateRendezVous());
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    public ArrayList<RendezVous> getRendezVousByDate(String dateDuJour) {
        ArrayList<RendezVous> rendezVousList = new ArrayList<>();

        try (Connection conn = getConnection()) {
            String SQL_FIND_BY_DATE = "SELECT idPatient, idMedecin, dateRendezVous FROM rendez_vous WHERE dateRendezVous = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_FIND_BY_DATE, dateDuJour);
            ResultSet rs = statement.executeQuery();

            while (rs.next()) {
                int idPatient = rs.getInt("idPatient");
                int idMedecin = rs.getInt("idMedecin");
                String dateRendezVous = rs.getString("dateRendezVous");
                RendezVous rendezVous = new RendezVous(idPatient, idMedecin, dateRendezVous);
                rendezVousList.add(rendezVous);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return rendezVousList;
    }

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/rv";
        String username = "votre_nom_utilisateur";
        String password = "votre_mot_de_passe";
        return DriverManager.getConnection(url, username, password);
    }

    private PreparedStatement prepareStatement(Connection conn, String sql, Object... params) throws SQLException {
        PreparedStatement statement = conn.prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            statement.setObject(i + 1, params[i]);
        }
        return statement;
    }

    private int executeUpdate(Connection conn, PreparedStatement statement) throws SQLException {
        return statement.executeUpdate();
    }
    /**
     * @param idMedecin
     * @param dateDuJour
     * @return
     */

    public boolean annulerRendezVous(int idRendezVousAAnnuler) {
        try (Connection conn = getConnection()) {
            String SQL_DELETE = "DELETE FROM rendez_vous WHERE idRendezVous = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_DELETE, idRendezVousAAnnuler);
            int rowsDeleted = statement.executeUpdate();
    
            if (rowsDeleted > 0) {
              
                return true;
            } else {
               
                return false;
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<RendezVous> getRendezVousMedecinByDate(int idMedecinRv, String dateDuJourRv) {
        return null;
    }
    
}
