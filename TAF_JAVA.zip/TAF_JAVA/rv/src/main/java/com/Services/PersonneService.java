package com.Services;

import com.entities.Personne;

public interface PersonneService extends IService<Personne> {
}
