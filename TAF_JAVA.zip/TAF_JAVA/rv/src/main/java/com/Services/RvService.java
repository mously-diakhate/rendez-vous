package com.Services;

import com.entities.Personne;

public interface RvService extends IService<Personne> {
}
