package com.entities;

public class RendezVous {

    public RendezVous(int idPatient, int idMedecin, String dateRendezVous) {
    }

    public String getIdPatient() {
        return null;
    }

    public String getDateRendezVous() {
        return null;
    }

    public String getIdMedecin() {
        return null;
    }

}
