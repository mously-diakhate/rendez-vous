package com.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public abstract class Personne {
    protected int id;
    protected String nomComplet;
    

    public Personne() {
    }

    public Personne(int id, String nomComplet) {
        this.id = id;
        this.nomComplet = nomComplet;
    }

    public Personne(String nomComplet) {
        this.id = generateUniqueId(); 
        this.nomComplet = nomComplet;
    }

   
    private int generateUniqueId() {
        
        return Personne.getNextId();
    }

    private static int getNextId() {
        return 0;
    }
}
