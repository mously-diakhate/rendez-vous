package com.entities;

public class Patient extends Personne {
    private String antecedents;
    private String type;

    public Patient() {
        super();
    }

    public Patient(int id, String nomComplet, String antecedents) {
        super(id, nomComplet);
        this.antecedents = antecedents;
    }

    

    public Object getType() {
        return null;
    }

    public Object getAntecedent() {
        return null;
    }
    public Patient(String nomComplet, String antecedent) {
        this.nomComplet = nomComplet;
        this.antecedents = antecedent;
        this.type = "Patient"; 
    }

	public void setType(String string) {
	}

}
