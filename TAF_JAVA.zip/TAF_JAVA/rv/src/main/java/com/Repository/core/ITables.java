package com.Repository.core;

import com.entities.Personne;

import java.util.ArrayList;

public interface ITables<T extends  Personne>  {

    int insert(Personne personne);

    int update(Personne personne);

    ArrayList<Personne> findAll();

    T findByID (int id);

    int delete (int id);

    int indexOf (int id);
}
