package com.Repository.bd;

import com.entities.Medecin;
import com.Repository.core.ITables;

public interface MedecinRepository extends ITables<Medecin> {

}
