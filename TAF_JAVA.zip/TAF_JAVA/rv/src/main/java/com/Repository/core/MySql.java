package com.Repository.core;

public class MySql extends DataBaseImpl {
    
}
