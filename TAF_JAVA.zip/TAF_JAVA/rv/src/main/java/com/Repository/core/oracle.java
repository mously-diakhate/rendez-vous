package com.Repository.core;

public class oracle {
    
}
