package com.Repository.bd.impl;

import com.entities.Personne;
import com.entities.Patient;
import com.Repository.bd.MysqlRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PatientRepositoryImpl extends MysqlRepository<Patient> {
    @Override
    public int insert(Personne data) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            Patient patient = (Patient) data;
            String SQL_INSERT = "INSERT INTO `personne` (`id`, `nomComplet`, `type`, `antecedent`) VALUES (NULL, ?, ?, ?)";
            PreparedStatement statement = prepareStatement(conn, SQL_INSERT, patient.getNomComplet(), patient.getType(), patient.getAntecedent());
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    @Override
    public int update(Personne data) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            Patient patient = (Patient) data;
            String SQL_UPDATE = "UPDATE `personne` SET `nomComplet` = ?, `antecedent` = ? WHERE `id` = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_UPDATE, patient.getNomComplet(), patient.getAntecedent(), patient.getId());
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    @Override
    public ArrayList<Personne> findAll() {
        ArrayList<Personne> resultList = new ArrayList<>();
        try (Connection conn = getConnection()) {
            String SQL_FIND_ALL = "SELECT id, nomComplet, type, antecedent FROM personne WHERE type = 'Patient'";
            PreparedStatement statement = prepareStatement(conn, SQL_FIND_ALL);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                Patient entity = new Patient(
                    rs.getInt("id"),
                    rs.getString("nomComplet"),
                    rs.getString("type")
                );
                resultList.add(entity);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resultList;
    }

    @Override
    public Personne findByID(int id) {
        Patient entity = null;
        try (Connection conn = getConnection()) {
            String SQL_FIND = "SELECT id, nomComplet, type, antecedent FROM personne WHERE type = 'Patient' AND id = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_FIND, id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                entity = new Patient(
                    rs.getInt("id"),
                    rs.getString("nomComplet"),
                    rs.getString("type")
                );
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return entity;
    }

    @Override
    public int delete(int id) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            String SQL_DELETE = "DELETE FROM `personne` WHERE `type` = 'Patient' AND `id` = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_DELETE, id);
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    @Override
    public int indexOf(int id) {
        
        return 0;
    }
}
