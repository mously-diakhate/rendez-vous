package com.Repository.bd;

import com.entities.Patient;
import com.Repository.core.ITables;

public interface PatientRepository extends ITables<Patient> {

}
