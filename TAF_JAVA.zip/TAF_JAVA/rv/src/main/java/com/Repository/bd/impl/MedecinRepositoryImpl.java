package com.Repository.bd.impl;

import com.entities.Personne;
import com.entities.Medecin;
import com.Repository.bd.MysqlRepository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MedecinRepositoryImpl extends MysqlRepository<Medecin> {
    @Override
    public int insert(Personne data) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            Medecin med = (Medecin) data;
            String SQL_INSERT = "INSERT INTO `personne` (`id`, `nomComplet`, `type`, `specialite_id`) VALUES (NULL, ?, ?, ?, ?)";
            PreparedStatement statement = prepareStatement(conn, SQL_INSERT, med.getNomComplet(), med.getType(), med.getSpecialite());
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    @Override
    public int update(Personne data) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            Medecin med = (Medecin) data;
            String SQL_UPDATE = "UPDATE `personne` SET `nomComplet` = ?, `specialite_id` = ? WHERE `id` = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_UPDATE, med.getNomComplet(), med.getSpecialite(), med.getId());
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }
    @Override
    public ArrayList<Personne> findAll() {
        ArrayList<Personne> resultList = new ArrayList<>();
        try (Connection conn = getConnection()) {
            String SQL_FIND_ALL = "SELECT id, nomComplet, specialite_id FROM personne WHERE type = 'Medecin'";
            PreparedStatement statement = prepareStatement(conn, SQL_FIND_ALL);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nomComplet = rs.getString("nomComplet");
                int specialite_id = rs.getInt("specialite_id");
                
                Medecin entity = new Medecin(nomComplet, specialite_id);
                entity.setId(id); 
    
                resultList.add(entity);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return resultList;
    }
    
    
    @Override
    public Personne findByID(int id) {
        Medecin entity = null;
        try (Connection conn = getConnection()) {
            String SQL_FIND = "SELECT id, nomComplet, type, antecedent, specialite_id FROM personne WHERE type = 'Medecin' AND id = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_FIND, id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                entity = new Medecin(
                );
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return entity;
    }
    

    @Override
    public int delete(int id) {
        int nbrLigne = 0;
        try (Connection conn = getConnection()) {
            String SQL_DELETE = "DELETE FROM `personne` WHERE `type` = 'Medecin' AND `id` = ?";
            PreparedStatement statement = prepareStatement(conn, SQL_DELETE, id);
            nbrLigne = executeUpdate(conn, statement);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return nbrLigne;
    }

    @Override
    public int indexOf(int id) {
       
        return 0;
    }
}
