package com.Repository.core;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public interface DataBase {
    void openConnection();
    void closeConnexion();
    ResultSet executeSelect(String sql);
    int executeUpdate(String sql);
    PreparedStatement getPs();


}
